const DEFAULTS = { platformSelect:'whatsapp',
  enabled:true,gainDb:42,loudnessBoostDb:0,thicknessDb:0,overdrivePct:0,autoRearm:true,autoUnmute:false,
  bassDb:3,warmthDb:2,mudCutDb:0,nasalCutDb:0,clarityDb:5,presenceDb:3,trebleDb:2,airDb:2,
  stageIntensity:55,distortionMode:'sharp_destroyer',distortionMixPct:35,pitchSemitones:0,
  echoPct:20,echoDelayMs:220,echoFeedbackPct:30
};

function sendSettings(settings) {
  const host = location.hostname;
  const selected = settings.platformSelect || 'whatsapp';
  const matches = selected === 'whatsapp' ? host === 'web.whatsapp.com'
    : selected === 'instagram' ? host === 'www.instagram.com' || host === 'instagram.com'
    : selected === 'snapchat' ? host === 'www.snapchat.com' || host === 'snapchat.com' : false;
  window.postMessage({ source: 'TOXIC_EXTENSION', type: 'SETTINGS',
    settings: { ...settings, enabled: !!settings.enabled && matches } }, '*');
}

window.addEventListener('message', async (e) => {
  if (e.source !== window || e.data?.source !== 'TOXIC_PAGE' || e.data?.type !== 'GET_SETTINGS') return;
  const s = await chrome.storage.local.get(DEFAULTS);
  sendSettings({ ...DEFAULTS, ...s });
});

chrome.storage.onChanged.addListener(async (_c, area) => {
  if (area !== 'local') return;
  const s = await chrome.storage.local.get(DEFAULTS);
  sendSettings({ ...DEFAULTS, ...s });
});

chrome.storage.local.get(DEFAULTS).then(s => sendSettings({ ...DEFAULTS, ...s }));

window.addEventListener('message', (e) => {
  if (e.source !== window || e.data?.source !== 'TOXIC_PAGE_METRICS' || e.data?.type !== 'AUDIO_METRICS') return;
  chrome.runtime.sendMessage({ type: 'TOXIC_AUDIO_METRICS', metrics: e.data.metrics }).catch(() => {});
});

// Optional cross-site unmute helper. Only activates when enabled and only
// clicks an explicitly labelled visible Unmute control.
let toxicAutoUnmute = false;
chrome.storage.local.get({autoUnmute:false}).then(v => { toxicAutoUnmute = !!v.autoUnmute; });
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.autoUnmute) toxicAutoUnmute = !!changes.autoUnmute.newValue;
});
let toxicLastUnmute = 0;
const toxicUnmuteObserver = new MutationObserver(() => {
  if (!toxicAutoUnmute) return;
  const now = Date.now();
  if (now - toxicLastUnmute < 1500) return;
  const candidates = document.querySelectorAll('button[aria-label],button[title],[role="button"][aria-label],[role="button"][title]');
  for (const el of candidates) {
    const label = `${el.getAttribute('aria-label') || ''} ${el.getAttribute('title') || ''}`.toLowerCase();
    if (/\\b(unmute|turn on microphone|enable microphone|mic on)\\b/.test(label) &&
        !/\\b(mute|turn off|disable)\\b/.test(label) && !el.disabled) {
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) { toxicLastUnmute = now; el.click(); break; }
    }
  }
});
toxicUnmuteObserver.observe(document.documentElement, {
  subtree:true, childList:true, attributes:true,
  attributeFilter:['aria-label','title','disabled']
});
