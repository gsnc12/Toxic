const DEFAULTS={platformSelect:'whatsapp',enabled:true,gainDb:42,loudnessBoostDb:0,thicknessDb:0,overdrivePct:0,autoUnmute:false,distortionMode:'sharp_destroyer',autoRearm:true,bassDb:3,warmthDb:2,mudCutDb:0,nasalCutDb:0,clarityDb:5,presenceDb:3,trebleDb:2,airDb:2,stageIntensity:55,distortionMixPct:35,pitchSemitones:0,echoPct:20,echoDelayMs:220,echoFeedbackPct:30};
const PRESETS={
 clean:{...DEFAULTS,gainDb:32,loudnessBoostDb:2,thicknessDb:1,clarityDb:6,presenceDb:2,overdrivePct:0,distortionMixPct:0,stageIntensity:25,echoPct:0},
 broadcast:{...DEFAULTS,gainDb:42,loudnessBoostDb:4,clarityDb:8,presenceDb:6,trebleDb:4,airDb:3,mudCutDb:3,stageIntensity:50,distortionMixPct:10,echoPct:8},
 overdrive:{...DEFAULTS,gainDb:55,loudnessBoostDb:3,overdrivePct:72,distortionMixPct:68,distortionMode:'sharp_destroyer',clarityDb:7,presenceDb:7,stageIntensity:82,echoPct:18},
 thick:{...DEFAULTS,gainDb:38,thicknessDb:8,bassDb:5,warmthDb:5,mudCutDb:2,clarityDb:4,overdrivePct:12,distortionMixPct:12,stageIntensity:40,echoPct:8},
 radio:{...DEFAULTS,gainDb:44,mudCutDb:5,nasalCutDb:3,clarityDb:9,presenceDb:8,trebleDb:5,airDb:2,bassDb:-3,stageIntensity:65,overdrivePct:22,distortionMixPct:28,echoPct:0},
 echo:{...DEFAULTS,gainDb:38,clarityDb:6,presenceDb:4,echoPct:68,echoFeedbackPct:66,echoDelayMs:280,stageIntensity:75,overdrivePct:12,distortionMixPct:20}
};
const ids=Object.keys(DEFAULTS).filter(id=>id!=='platformSelect'),$=id=>document.getElementById(id);let saveTimer;
function format(id,v){if(id==='gainDb')return `${v} / 99`;if(id==='pitchSemitones')return `${v} st`;if(id==='echoDelayMs')return `${v} ms`;if(id.endsWith('Db'))return `${Number(v)>0?'+':''}${v} dB`;return `${v}%`;}
function display(){for(const id of ids){const el=$(id),out=$(id+'Value');if(el&&out)out.textContent=id==='enabled'||id==='autoRearm'?'':format(id,el.value);if(el?.type==='range'){const min=Number(el.min||0),max=Number(el.max||100),pct=(Number(el.value)-min)/(max-min)*100;el.style.setProperty('--pct',`${pct}%`);el.parentElement?.style.setProperty('--angle',`${-135+pct*2.7}deg`);}}}
function values(){const o={};for(const id of ids){const el=$(id);if(el)o[id]=el.type==='checkbox'?el.checked:(id==='distortionMode'?el.value:Number(el.value));}return o;}
function send(){const v=values();v.platformSelect=$('platformSelect').value;chrome.storage.local.set(v);}
function fill(data){for(const id of ids){const el=$(id);if(!el)continue;if(el.type==='checkbox')el.checked=!!data[id];else el.value=data[id]??DEFAULTS[id];}display();}
function mark(name){document.querySelectorAll('.preset').forEach(b=>b.classList.toggle('active',b.dataset.preset===name));}
chrome.storage.local.get(DEFAULTS,data=>{fill({...DEFAULTS,...data});$('platformSelect').value=data.platformSelect||'whatsapp';});
$('platformSelect').addEventListener('change',()=>{send();$('meterStatus').textContent=`DSP target set to ${$('platformSelect').selectedOptions[0].text}`;});
ids.forEach(id=>$(id)?.addEventListener('input',()=>{display();clearTimeout(saveTimer);saveTimer=setTimeout(send,70);}));
$('save').onclick=()=>{send();$('save').textContent='SAVED ✓';setTimeout(()=>$('save').textContent='SAVE PROFILE',1000);};
$('reset').onclick=()=>{fill(DEFAULTS);send();mark('');};
document.querySelectorAll('.preset').forEach(btn=>btn.addEventListener('click',()=>{fill(PRESETS[btn.dataset.preset]);send();mark(btn.dataset.preset);}));
const canvas=$('waveform'),waveCtx=canvas.getContext('2d'),sc=$('spectrum'),sctx=sc.getContext('2d');let wave=Array(96).fill(0),spectrum=Array(48).fill(0),seen=false;
function draw(){const w=canvas.width,h=canvas.height;waveCtx.clearRect(0,0,w,h);waveCtx.fillStyle='#f8f7ff';waveCtx.fillRect(0,0,w,h);waveCtx.strokeStyle='#e3def5';for(let y=15;y<h;y+=20){waveCtx.beginPath();waveCtx.moveTo(0,y);waveCtx.lineTo(w,y);waveCtx.stroke();}waveCtx.strokeStyle='#7657e8';waveCtx.lineWidth=2.5;waveCtx.beginPath();wave.forEach((v,i)=>{const x=i/(wave.length-1)*w,y=h/2-v*h*.46;i?waveCtx.lineTo(x,y):waveCtx.moveTo(x,y);});waveCtx.stroke();sctx.clearRect(0,0,sc.width,sc.height);sctx.fillStyle='#f8f7ff';sctx.fillRect(0,0,sc.width,sc.height);const bw=sc.width/spectrum.length-2;spectrum.forEach((v,i)=>{sctx.fillStyle=i>30?'#13b8a6':'#7657e8';sctx.fillRect(i*(bw+2),sc.height, bw,-Math.max(2,v*sc.height));});}draw();
chrome.runtime.onMessage.addListener(msg=>{if(msg?.type!=='TOXIC_AUDIO_METRICS')return;seen=true;const m=msg.metrics||{};if(Array.isArray(m.waveform))wave=m.waveform.slice(-96);if(Array.isArray(m.spectrum))spectrum=m.spectrum.slice(-48);draw();if(Number.isFinite(Number(m.peakDb)))$('peakValue').textContent=`PEAK ${Number(m.peakDb).toFixed(1)} dBFS`;const clip=!!m.clipping;$('clipBadge').textContent=clip?'CLIP / HOT':'NO CLIP';$('clipBadge').classList.toggle('hot',clip);$('signalState').textContent=m.active?'LIVE INPUT':'MIC IDLE';$('meterStatus').textContent=m.active?'Microphone processing active':'Waiting for voice input';});
setInterval(()=>{if(!seen)$('meterStatus').textContent='Open the selected platform and start or refresh a call tab';},2500);
