(() => {
  if (window.__toxicMicInstalled) return;
  window.__toxicMicInstalled = true;

  const cfg = {
    enabled: true,
    gainDb: 42, loudnessBoostDb: 0, thicknessDb: 0, overdrivePct: 0, autoRearm: true, autoUnmute: false,
    bassDb: 3, warmthDb: 2, mudCutDb: 0, nasalCutDb: 0, clarityDb: 5, presenceDb: 3, trebleDb: 2, airDb: 2,
    stageIntensity: 55, distortionMode: 'sharp_destroyer', distortionMixPct: 35,
    pitchSemitones: 0,
    echoPct: 60,
    echoDelayMs: 220,
    echoFeedbackPct: 65
  };

  const pipelines = new WeakMap();
  const processedTracks = new WeakSet();

  // UI gain is a 0-99 drive scale mapped to a bounded +0..36 dB digital gain.
  // A separate loudness stage adds up to +24 dB; neither value represents acoustic SPL.
  const dbToLinear = db => Math.pow(10, Math.max(0, Math.min(60, Number(db) || 0)) / 20);
  const gainScaleToDb = v => Math.pow(Math.max(0, Math.min(99, Number(v) || 0)) / 99, 1.35) * 36;
  const num = (k, d = 0) => Number.isFinite(Number(cfg[k])) ? Number(cfg[k]) : d;

  function makeDistortionCurve(amount, mode = 'sharp_destroyer') {
    const n = 65536;
    const curve = new Float32Array(n);
    const a = Math.max(0, Math.min(100, Number(amount) || 0)) / 100;
    const drive = 1 + a * 110;

    for (let i = 0; i < n; i++) {
      const x = (i * 2 / (n - 1)) - 1;
      let y;

      if (mode === 'sharp_destroyer') {
        const driven = x * drive;
        y = Math.sign(x) * (0.65 * Math.tanh(Math.abs(driven)) + 0.35 * Math.sin(Math.min(Math.PI / 2, Math.abs(x * drive * 1.5))));
        y = Math.max(-1, Math.min(1, y * 1.35));
      } else if (mode === 'hard') {
        const d = 1 + a * 20;
        y = Math.max(-1, Math.min(1, x * d));
      } else if (mode === 'fuzz') {
        y = Math.sign(x) * Math.pow(Math.abs(Math.sin(x * drive)), 0.62);
      } else if (mode === 'fold') {
        y = (2 / Math.PI) * Math.asin(Math.sin(x * drive));
      } else {
        y = Math.tanh(x * (1 + a * 24)) / Math.tanh(1 + a * 24);
      }
      curve[i] = y;
    }
    return curve;
  }

  class PitchShifterEngine {
    constructor(ctx) {
      this.ctx = ctx;
      this.input = ctx.createGain();
      this.output = ctx.createGain();
      this.dryGain = ctx.createGain();
      this.wetGain = ctx.createGain();

      this.delayA = ctx.createDelay(1.0);
      this.delayB = ctx.createDelay(1.0);
      this.fadeA = ctx.createGain();
      this.fadeB = ctx.createGain();

      this.input.connect(this.dryGain);
      this.dryGain.connect(this.output);

      this.input.connect(this.delayA);
      this.input.connect(this.delayB);
      this.delayA.connect(this.fadeA);
      this.delayB.connect(this.fadeB);
      this.fadeA.connect(this.wetGain);
      this.fadeB.connect(this.wetGain);
      this.wetGain.connect(this.output);

      this.lfoA = null;
      this.lfoB = null;
      this.fadeLfoA = null;
      this.fadeLfoB = null;
      this.windowSize = 0.055;
      this.setPitch(0);
    }

    setPitch(semitones) {
      const semi = Math.max(-12, Math.min(12, Number(semitones) || 0));
      const t = this.ctx.currentTime;

      if (Math.abs(semi) < 0.2) {
        this.dryGain.gain.setTargetAtTime(1, t, 0.015);
        this.wetGain.gain.setTargetAtTime(0, t, 0.015);
        this.stopLFOs();
        return;
      }

      this.dryGain.gain.setTargetAtTime(0, t, 0.015);
      this.wetGain.gain.setTargetAtTime(1, t, 0.015);

      const ratio = Math.pow(2, semi / 12);
      const rate = (1 - ratio) / this.windowSize;
      const freq = Math.abs(rate);

      this.rebuildLFOs(freq, rate > 0);
    }

    stopLFOs() {
      if (this.lfoA) { try { this.lfoA.stop(); this.lfoA.disconnect(); } catch (_) {} this.lfoA = null; }
      if (this.lfoB) { try { this.lfoB.stop(); this.lfoB.disconnect(); } catch (_) {} this.lfoB = null; }
      if (this.fadeLfoA) { try { this.fadeLfoA.stop(); this.fadeLfoA.disconnect(); } catch (_) {} this.fadeLfoA = null; }
      if (this.fadeLfoB) { try { this.fadeLfoB.stop(); this.fadeLfoB.disconnect(); } catch (_) {} this.fadeLfoB = null; }
    }

    rebuildLFOs(freq, isDown) {
      this.stopLFOs();
      if (freq < 0.001) return;

      const sr = this.ctx.sampleRate;
      const length = Math.max(256, Math.floor(sr / freq));
      const modBufferA = this.ctx.createBuffer(1, length, sr);
      const modBufferB = this.ctx.createBuffer(1, length, sr);
      const fadeBufferA = this.ctx.createBuffer(1, length, sr);
      const fadeBufferB = this.ctx.createBuffer(1, length, sr);

      const dA = modBufferA.getChannelData(0);
      const dB = modBufferB.getChannelData(0);
      const fA = fadeBufferA.getChannelData(0);
      const fB = fadeBufferB.getChannelData(0);

      const win = this.windowSize;
      const half = length / 2;

      for (let i = 0; i < length; i++) {
        const phA = i / length;
        const phB = ((i + half) % length) / length;

        dA[i] = isDown ? phA * win : (1 - phA) * win;
        dB[i] = isDown ? phB * win : (1 - phB) * win;

        fA[i] = Math.sin(phA * Math.PI);
        fB[i] = Math.sin(phB * Math.PI);
      }

      this.lfoA = this.ctx.createBufferSource();
      this.lfoA.buffer = modBufferA;
      this.lfoA.loop = true;

      this.lfoB = this.ctx.createBufferSource();
      this.lfoB.buffer = modBufferB;
      this.lfoB.loop = true;

      this.fadeLfoA = this.ctx.createBufferSource();
      this.fadeLfoA.buffer = fadeBufferA;
      this.fadeLfoA.loop = true;

      this.fadeLfoB = this.ctx.createBufferSource();
      this.fadeLfoB.buffer = fadeBufferB;
      this.fadeLfoB.loop = true;

      this.lfoA.connect(this.delayA.delayTime);
      this.lfoB.connect(this.delayB.delayTime);
      this.fadeLfoA.connect(this.fadeA.gain);
      this.fadeLfoB.connect(this.fadeB.gain);

      this.lfoA.start();
      this.lfoB.start();
      this.fadeLfoA.start();
      this.fadeLfoB.start();
    }
  }

  function updatePipeline(p) {
    const on = !!cfg.enabled;
    const t = p.ctx.currentTime;
    const gainDb = gainScaleToDb(num('gainDb', 42)) + Math.max(0, Math.min(24, num('loudnessBoostDb', 0)));
    p.gain.gain.setTargetAtTime(on ? dbToLinear(gainDb) : 1, t, 0.025);

    const stage = Math.max(0, Math.min(1, num('stageIntensity', 55) / 100));
    p.lowCut.frequency.setTargetAtTime(on ? 75 : 10, t, 0.03);
    p.bass.gain.setTargetAtTime(on ? num('bassDb', 3) : 0, t, 0.03);
    p.warmth.gain.setTargetAtTime(on ? num('warmthDb', 2) + num('thicknessDb', 0) * 0.45 : 0, t, 0.03);
    p.thickness.gain.setTargetAtTime(on ? num('thicknessDb', 0) : 0, t, 0.03);
    p.mudCut.gain.setTargetAtTime(on ? -Math.abs(num('mudCutDb', 0)) : 0, t, 0.03);
    p.nasalCut.gain.setTargetAtTime(on ? -Math.abs(num('nasalCutDb', 0)) : 0, t, 0.03);
    p.clarity.gain.setTargetAtTime(on ? num('clarityDb', 5) + stage * 2 : 0, t, 0.03);
    p.presence.gain.setTargetAtTime(on ? num('presenceDb', 3) * (0.35 + stage * 0.65) : 0, t, 0.03);
    p.treble.gain.setTargetAtTime(on ? num('trebleDb', 2) : 0, t, 0.03);
    p.superAir.gain.setTargetAtTime(on ? num('airDb', 2) : 0, t, 0.03);

    const drive = Math.max(0, Math.min(100, num('overdrivePct', 0)));
    const mix = Math.max(0, Math.min(100, num('distortionMixPct', 35))) / 100;
    p.cleanDirectGain.gain.setTargetAtTime(1, t, 0.02);
    p.distWetGain.gain.setTargetAtTime(on ? Math.min(0.9, mix * (0.25 + stage * 0.75)) : 0, t, 0.02);
    p.shaper.curve = on ? makeDistortionCurve(drive, cfg.distortionMode || 'sharp_destroyer') : makeDistortionCurve(0, 'soft');

    p.pitchShifter.setPitch(on ? num('pitchSemitones', 0) : 0);
    const echoAmt = Math.max(0, Math.min(100, num('echoPct', 20))) / 100;
    const echoDelay = Math.max(0.04, Math.min(1.2, num('echoDelayMs', 220) / 1000));
    const feedback = Math.max(0, Math.min(0.8, num('echoFeedbackPct', 30) / 100));
    p.delay.delayTime.setTargetAtTime(echoDelay, t, 0.03);
    p.echoGain.gain.setTargetAtTime(on ? echoAmt * (0.25 + stage * 0.75) * 0.65 : 0, t, 0.03);
    p.echoFeedback.gain.setTargetAtTime(on ? feedback : 0, t, 0.03);
  }

  window.addEventListener('message', (e) => {
    if (e.source !== window || e.data?.source !== 'TOXIC_EXTENSION' || e.data?.type !== 'SETTINGS') return;
    Object.assign(cfg, e.data.settings || {});
    if (window.__toxicMicPipelines) {
      for (const p of window.__toxicMicPipelines) updatePipeline(p);
    }
  });

  function startTelemetry(p) {
    if (p.telemetryTimer) return;
    const samples = new Float32Array(p.analyser.fftSize);
    const freq = new Uint8Array(p.analyser.frequencyBinCount);
    let lastPost = 0;

    p.telemetryTimer = setInterval(() => {
      if (p.ctx.state === 'closed') return;
      p.analyser.getFloatTimeDomainData(samples);
      p.analyser.getByteFrequencyData(freq);

      let peak = 0;
      let clipped = 0;
      const waveform = [];
      const bucket = Math.max(1, Math.floor(samples.length / 96));

      for (let i = 0; i < samples.length; i++) {
        const a = Math.abs(samples[i]);
        if (a > peak) peak = a;
        if (a >= 0.985) clipped++;
      }

      for (let i = 0; i < 96; i++) {
        let v = 0;
        const start = i * bucket;
        const end = Math.min(samples.length, start + bucket);
        for (let j = start; j < end; j++) {
          if (Math.abs(samples[j]) > Math.abs(v)) v = samples[j];
        }
        waveform.push(v);
      }

      const spectrum = [];
      for (let i = 0; i < 48; i++) {
        const start = Math.floor(i * freq.length / 48);
        const end = Math.max(start + 1, Math.floor((i + 1) * freq.length / 48));
        let max = 0;
        for (let j = start; j < end; j++) max = Math.max(max, freq[j]);
        spectrum.push(max / 255);
      }

      const now = Date.now();
      if (now - lastPost < 80) return;
      lastPost = now;

      const peakDb = peak > 0 ? 20 * Math.log10(peak) : -100;
      window.postMessage({
        source: 'TOXIC_PAGE_METRICS',
        type: 'AUDIO_METRICS',
        metrics: { waveform, spectrum, peakDb, clipping: clipped > 0, active: peak > 0.0003 }
      }, '*');
    }, 80);
  }

  function buildPipeline(stream) {
    const track = stream.getAudioTracks()[0];
    if (!track) return stream;
    if (pipelines.has(track)) return pipelines.get(track);

    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return stream;
    let ctx;
    try { ctx = new AC({ latencyHint: 'interactive' }); } catch (_) { ctx = new AC(); }

    const source = ctx.createMediaStreamSource(stream);
    const pitchShifter = new PitchShifterEngine(ctx);

    const lowCut = ctx.createBiquadFilter();
    lowCut.type = 'highpass';
    lowCut.frequency.value = 70;

    const bass = ctx.createBiquadFilter();
    bass.type = 'lowshelf';
    bass.frequency.value = 140;

    const warmth = ctx.createBiquadFilter();
    warmth.type = 'peaking';
    warmth.frequency.value = 280;
    warmth.Q.value = 0.9;

    const thickness = ctx.createBiquadFilter();
    thickness.type = 'peaking'; thickness.frequency.value = 190; thickness.Q.value = 0.85;
    const mudCut = ctx.createBiquadFilter();
    mudCut.type = 'peaking'; mudCut.frequency.value = 420; mudCut.Q.value = 1.1;
    const nasalCut = ctx.createBiquadFilter();
    nasalCut.type = 'peaking'; nasalCut.frequency.value = 1050; nasalCut.Q.value = 1.3;

    const clarity = ctx.createBiquadFilter();
    clarity.type = 'peaking';
    clarity.frequency.value = 3500;
    clarity.Q.value = 1.1;

    const presence = ctx.createBiquadFilter();
    presence.type = 'peaking'; presence.frequency.value = 4500; presence.Q.value = 1.0;

    const treble = ctx.createBiquadFilter();
    treble.type = 'highshelf';
    treble.frequency.value = 7500;

    const superAir = ctx.createBiquadFilter();
    superAir.type = 'highshelf';
    superAir.frequency.value = 10000;
    superAir.Q.value = 1.2;

    const gain = ctx.createGain();
    const stackPre = ctx.createGain();
    const stackPost = ctx.createGain();

    const cleanDirectGain = ctx.createGain();
    cleanDirectGain.gain.value = 1.0;

    const distPreFilter = ctx.createBiquadFilter();
    distPreFilter.type = 'highpass';
    distPreFilter.frequency.value = 360;
    const shaper = ctx.createWaveShaper();
    shaper.oversample = '4x';
    shaper.curve = makeDistortionCurve(55, 'sharp_destroyer');
    const distWetGain = ctx.createGain();
    distWetGain.gain.value = 0.65;

    const voiceBus = ctx.createGain();
    const finalBus = ctx.createGain();
    const peakSaturator = ctx.createWaveShaper();
    peakSaturator.curve = Float32Array.from({length:2048}, (_,i) => { const x=i*2/2047-1; return Math.tanh(x*1.35)/Math.tanh(1.35); });
    peakSaturator.oversample = '4x';
    const dest = ctx.createMediaStreamDestination();

    const delay = ctx.createDelay(2.0);
    delay.delayTime.value = 0.22;
    const echoGain = ctx.createGain();
    echoGain.gain.value = 0.60;
    const echoFeedback = ctx.createGain();
    echoFeedback.gain.value = 0.65;

    const echoHighPass = ctx.createBiquadFilter();
    echoHighPass.type = 'highpass';
    echoHighPass.frequency.value = 350;
    const echoLowPass = ctx.createBiquadFilter();
    echoLowPass.type = 'lowpass';
    echoLowPass.frequency.value = 5200;

    source.connect(pitchShifter.input);
    pitchShifter.output.connect(lowCut);
    lowCut.connect(bass);
    bass.connect(warmth);
    warmth.connect(thickness);
    thickness.connect(mudCut);
    mudCut.connect(nasalCut);
    nasalCut.connect(clarity);
    clarity.connect(presence);
    presence.connect(treble);
    treble.connect(superAir);
    superAir.connect(gain);
    gain.connect(stackPre);

    stackPre.connect(cleanDirectGain);
    cleanDirectGain.connect(voiceBus);

    stackPre.connect(distPreFilter);
    distPreFilter.connect(shaper);
    shaper.connect(distWetGain);
    distWetGain.connect(voiceBus);

    voiceBus.connect(stackPost);
    stackPost.connect(finalBus);
    finalBus.connect(peakSaturator);
    peakSaturator.connect(dest);

    stackPost.connect(delay);
    delay.connect(echoHighPass);
    echoHighPass.connect(echoLowPass);
    echoLowPass.connect(echoGain);
    echoGain.connect(finalBus);

    echoLowPass.connect(echoFeedback);
    echoFeedback.connect(delay);

    const analyser = ctx.createAnalyser();
    analyser.fftSize = 2048;
    analyser.smoothingTimeConstant = 0.25;
    finalBus.connect(analyser);

    const out = dest.stream.getAudioTracks()[0];
    processedTracks.add(out);

    const p = {
      ctx, stream, outputTrack: out, gain, stackPre, stackPost,
      lowCut, bass, warmth, thickness, mudCut, nasalCut, clarity, presence, treble, superAir,
      pitchShifter, cleanDirectGain, distWetGain, shaper,
      delay, echoGain, echoFeedback, finalBus, peakSaturator, analyser,
      telemetryTimer: null
    };

    pipelines.set(track, p);
    if (cfg.autoRearm !== false) {
      const resume = () => { if (p.ctx.state === 'suspended') p.ctx.resume().catch(() => {}); updatePipeline(p); };
      track.addEventListener('unmute', resume);
      track.addEventListener('ended', () => { try { clearInterval(p.telemetryTimer); p.ctx.close(); } catch (_) {} }, { once: true });
    }
    if (!window.__toxicMicPipelines) window.__toxicMicPipelines = new Set();
    window.__toxicMicPipelines.add(p);

    updatePipeline(p);
    ctx.resume().catch(() => {});
    startTelemetry(p);

    return p;
  }

  if (navigator.mediaDevices?.getUserMedia) {
    const md = navigator.mediaDevices;
    const origGUM = md.getUserMedia.bind(md);

    md.getUserMedia = async function (constraints) {
      const stream = await origGUM(constraints);
      if (!stream?.getAudioTracks().length || cfg.enabled === false) return stream;
      try {
        const p = buildPipeline(stream);
        if (!p?.outputTrack) return stream;
        return new MediaStream([...stream.getVideoTracks(), p.outputTrack]);
      } catch (err) {
        return stream;
      }
    };
  }

  const PC = window.RTCPeerConnection;
  if (PC?.prototype?.addTrack && !PC.prototype.addTrack.__toxicWrapped) {
    const origAddTrack = PC.prototype.addTrack;
    const wrappedAddTrack = function (track, ...streams) {
      if (track?.kind === 'audio' && !processedTracks.has(track)) {
        const p = pipelines.get(track);
        if (p?.outputTrack && p.outputTrack.readyState === 'live') {
          track = p.outputTrack;
        }
      }
      return origAddTrack.call(this, track, ...streams);
    };
    wrappedAddTrack.__toxicWrapped = true;
    PC.prototype.addTrack = wrappedAddTrack;
  }

  if (window.RTCRtpSender && RTCRtpSender.prototype.replaceTrack && !RTCRtpSender.prototype.replaceTrack.__toxicWrapped) {
    const origReplaceTrack = RTCRtpSender.prototype.replaceTrack;
    const wrappedReplaceTrack = function (track) {
      if (track?.kind === 'audio' && !processedTracks.has(track)) {
        const p = pipelines.get(track);
        if (p?.outputTrack && p.outputTrack.readyState === 'live') {
          track = p.outputTrack;
        }
      }
      return origReplaceTrack.call(this, track);
    };
    wrappedReplaceTrack.__toxicWrapped = true;
    RTCRtpSender.prototype.replaceTrack = wrappedReplaceTrack;
  }

  window.postMessage({ source: 'TOXIC_PAGE', type: 'GET_SETTINGS' }, '*');
})();
