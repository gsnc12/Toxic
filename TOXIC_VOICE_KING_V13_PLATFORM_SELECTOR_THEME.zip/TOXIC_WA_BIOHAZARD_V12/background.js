chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  }
});

chrome.action.onClicked.addListener((tab) => {
  if (!chrome.sidePanel || typeof chrome.sidePanel.open !== 'function') return;
  if (typeof tab.windowId !== 'number') return;
  chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {});
});
