TOXIC VOICE KING V13 — WhatsApp, Instagram & Snapchat Web

INSTALL
1. Extract the ZIP to a normal folder.
2. Open chrome://extensions (or edge://extensions).
3. Enable Developer mode.
4. Choose Load unpacked and select the folder containing manifest.json.
5. Open or refresh one of these sites and start a supported browser call:\n   - https://web.whatsapp.com\n   - https://www.instagram.com\n   - https://www.snapchat.com
6. Open the extension side panel from the toolbar icon.

CONTROLS
- Gain Drive: 0–99 user scale mapped to a bounded digital gain range.
- Loudness+: separate post-gain lift.
- Thickness: dedicated low-mid EQ control; it does not change pitch.
- Overdrive: parallel harmonic saturation, with selectable character.
- Stage 3+4 master: linked presence / drive blend / echo-send intensity.
- Additional EQ: bass, body, mud cut, nasal cut, clarity, presence, treble and air.
- Pitch shifter remains a separate control.
- Auto-unmute is opt-in and clicks a visible, explicitly labelled Unmute control where the site exposes one when detected. It can override a manual mute while enabled. Browser microphone permission is still required.
- Auto-rearm resumes the audio context when an existing microphone track unmutes and cleans up when the track ends.

AUDIO NOTES
A browser extension cannot create literal 99 dB SPL from a microphone. The 0–99 gain dial is a drive scale mapped to a bounded digital gain range; Loudness+ adds a separate digital boost. Actual level depends on microphone sensitivity, OS input level, browser processing, codec and the receiving device. Excessive digital gain can clip. A static soft-saturation stage catches peaks; there is no compressor, gate, or automatic gain-reduction/ducking stage in this build.

The extension requires microphone permission from the browser and WhatsApp. Audio processing starts when the calling site requests a microphone stream; refresh the WhatsApp tab after installing or updating.
\n\nSITE COMPATIBILITY NOTE\nThis package injects the same microphone-processing engine on the listed web origins. Instagram and Snapchat can change their call UI and media routing at any time; the extension cannot process calls that use a separate native app, protected/isolated media path, or a page that does not request microphone access through standard browser media APIs. Auto-unmute is best-effort and cannot override a remote mute, site-enforced mute, browser permission denial, or a control whose label is not exposed to the page.\n